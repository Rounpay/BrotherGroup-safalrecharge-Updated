package com.lk.qf.pay.callback;

public interface MPosStatusListener {
	public abstract void onError(int errCode,String errMsg);
	public abstract void onChange(int status);
}
