package com.lk.qf.pay.standard;

public class MPosInfo {
	private String productModel; //��Ʒ�ͺ�
	private String softVer; //�����汾
	private String hardSN; //Ӳ�����к�
	private String clientSN; //�ͻ������ն����к�,��KSN
	
	public String getProductModel() {
		return productModel;
	}
	public void setProductModel(String productModel) {
		this.productModel = productModel;
	}
	public String getSoftVer() {
		return softVer;
	}
	public void setSoftVer(String softVer) {
		this.softVer = softVer;
	}
	public String getHardSN() {
		return hardSN;
	}
	public void setHardSN(String hardSN) {
		this.hardSN = hardSN;
	}
	public String getClientSN() {
		return clientSN;
	}
	public void setClientSN(String clientSN) {
		this.clientSN = clientSN;
	}
}
