package com.lk.qf.pay.standard;

public class CardInfo {
	private String cardNo; //����
	private String track2; //������Ϣ(��������)
	private String track3; //������Ϣ(��������)
	private String icData; //ic����
	private String cardExp; //����Ч��
	private String panSerial; //�����к�
	private int cardType; //����ȡ��ʽ
	
	public final static int ShuaKa = 0;
	public final static int ChaKa = 1;
	public final static int HuiKa = 2;
	
	public String getCardNo() {
		return cardNo;
	}
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	public String getIcData() {
		return icData;
	}
	public void setIcData(String icData) {
		this.icData = icData;
	}
	public String getCardExp() {
		return cardExp;
	}
	public void setCardExp(String cardExp) {
		this.cardExp = cardExp;
	}
	public String getPanSerial() {
		return panSerial;
	}
	public void setPanSerial(String panSerial) {
		this.panSerial = panSerial;
	}
	public String getTrack2() {
		return track2;
	}
	public void setTrack2(String track2) {
		this.track2 = track2;
	}
	public String getTrack3() {
		return track3;
	}
	public void setTrack3(String track3) {
		this.track3 = track3;
	}
	public int getCardType() {
		return cardType;
	}
	public void setCardType(int cardType) {
		this.cardType = cardType;
	}
}
