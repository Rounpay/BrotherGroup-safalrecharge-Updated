package com.lk.qf.pay.standard;

public class MPosStatus {
	public static final int Connected=0;
	public static final int DisConnected=1;
	public static final int Connecting=2;
	public static final int Matching=3;
}
