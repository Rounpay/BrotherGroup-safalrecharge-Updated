package com.newland.emv.jni.type;

public class cardblk{
	public byte[] 	_card_no = new byte[10];                                   
	public byte 	_len;                              
	public byte 	_index;                                    
	public byte 	_disable;                             
	public byte 	_partial_match;                       
	public byte 	_disable_index;
	public byte 	_rsv;
}

