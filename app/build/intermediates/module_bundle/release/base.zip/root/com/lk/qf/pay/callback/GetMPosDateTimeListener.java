package com.lk.qf.pay.callback;

public interface GetMPosDateTimeListener {
	public abstract void onError(int errCode,String errMsg);
	//��ʽ:yyyyMMdd HHmmss
	public abstract void onSuccess(String dateTime);
}
