package com.newland.emv.jni.type;

public class certblk{
	public byte[] 	_rid = new byte[5];
	public byte 	_index;
	public byte[] 	_sn = new byte[3];
	public byte 	_disable;
	public byte[] 	_rsv = new byte[2];
}
