package com.lk.qf.pay.callback;

import com.lk.qf.pay.standard.MPosInfo;

public interface GetMPosInfoListener {
	public abstract void onError(int errCode,String errMsg);
	public abstract void onSuccess(MPosInfo deviceInfo);
}
