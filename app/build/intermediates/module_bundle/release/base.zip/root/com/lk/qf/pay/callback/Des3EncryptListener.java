package com.lk.qf.pay.callback;

public interface Des3EncryptListener {
	public abstract void onError(int errCode, String errDesc);
	public abstract void onSuccess(String result);
}
