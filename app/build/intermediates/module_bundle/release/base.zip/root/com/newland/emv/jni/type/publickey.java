package com.newland.emv.jni.type;

public class publickey{
	public byte[] 	pk_modulus = new byte[248];
	public int 	pk_mod_len;
	public byte[]	 pk_exponent = new byte[3];
}
