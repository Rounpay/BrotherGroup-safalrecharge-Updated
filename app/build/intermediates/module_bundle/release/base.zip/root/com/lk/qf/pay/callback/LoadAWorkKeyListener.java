package com.lk.qf.pay.callback;

public interface LoadAWorkKeyListener {
	public abstract void onError(int errCode, String errDesc);
	public abstract void onSuccess();
}
