package com.lk.qf.pay.callback;

public interface LoadCapkListener {
	public abstract void onError(int errCode,String errMsg);
	public abstract void onSuccess();
}
