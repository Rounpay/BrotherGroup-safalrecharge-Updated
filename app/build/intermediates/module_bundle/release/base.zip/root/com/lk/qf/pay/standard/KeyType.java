package com.lk.qf.pay.standard;

public class KeyType {
	public static final int PLAIN=0;
	public static final int CIPHER=1;
	public static final int PINK=2;
	public static final int MACK=3;
	public static final int TDK=4;
}
