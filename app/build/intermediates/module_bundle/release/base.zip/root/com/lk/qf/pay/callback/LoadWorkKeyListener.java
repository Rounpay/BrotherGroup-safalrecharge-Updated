package com.lk.qf.pay.callback;

public interface LoadWorkKeyListener {
	public abstract void onError(int errCode, String errDesc);
	public abstract void onSuccess();
}
