package com.lk.qf.pay.callback;

public interface GetMPosElectricityListener {
	public abstract void onError(int errCode,String errMsg);
	//�ٷֱȵ�����ֵ
	public abstract void onSuccess(int electricity);
}
