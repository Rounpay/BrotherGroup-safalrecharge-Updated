package com.lk.qf.pay.callback;

import com.lk.qf.pay.standard.CardInfo;

public interface GetCardInfoListener {
	public abstract void onError(int errCode, String errDesc);
	public abstract void onSuccess(CardInfo cardInfo);
}
